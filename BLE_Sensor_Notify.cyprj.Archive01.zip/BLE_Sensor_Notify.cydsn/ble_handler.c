/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "ble_handler.h"
#include "BLE.h"
#include "BLE_config.h"
#include "ble/cy_ble_ias.h"
#include "ble/cy_ble.h"

deviceInfo_t myDeviceInformation = {
                                   .mfg     =  NULL,
                                   .model   =  NULL,
                                   .SN      =  NULL,
                                   .FMWARE  =  NULL,
                                };
void ble_updateManufacturer_name(char8* name)   { myDeviceInformation.mfg     = name; }
void ble_updateModel(char8* model)              { myDeviceInformation.model   = model; }
void ble_updateSN(char8* SN)                    { myDeviceInformation.SN      = SN; }
void ble_updateFirmwareVersion(char8* version)  { myDeviceInformation.FMWARE  = version; }
void ble_updateDeviceInformation(deviceInfo_t *info)
{
    ble_updateManufacturer_name(info->mfg);
    ble_updateModel(info->model);
    ble_updateSN(info->SN);
    ble_updateFirmwareVersion(info->FMWARE);
}

void ble_updateBatteryValue(float battery_percent){
    ble_param.battery_level.value       =  battery_percent; 
    ble_param.battery_level.handler     = (uint8_t)WRITE_NOTIF;
};

void ble_updateTemperatureValue(float temperature){
    ble_param.temperature.value       =  temperature; 
    ble_param.temperature.handler     = (uint8_t)WRITE_NOTIF;
};

void ble_updatePressureValue(float pressure){
    ble_param.pressure.value       =  pressure; 
    ble_param.pressure.handler     = (uint8_t)WRITE_NOTIF;
};

void ble_updateCustomParamValue(float val){
    ble_param.custom.value       =  val; 
    ble_param.custom.handler     = (uint8_t)WRITE_NOTIF;
};

void ble_updateBASValue(uint8_t level){
    ble_param.BAS.value       = (float) level; 
    ble_param.BAS.handler     = (uint8_t)WRITE_NOTIF;
};

void ble_updateValueParam(ble_param_index id, float value)
{
    switch(id){
        case TEMPERATURE_IDX:
            ble_updateTemperatureValue(value);
            break;
        case PRESSURE_IDX:
            ble_updatePressureValue(value);
            break;
        case BATTERY_LEVEL_IDX:
            ble_updateBatteryValue(value);
            break;
        case CUSTOM_PARAM_IDX:
            ble_updateCustomParamValue(value);
            break;
        case BAS_LEVEL:
            ble_updateBASValue(value);
            break;
        default:
            break;
    };
}

static void ble_update_deviceInfo(void)
{
    if( myDeviceInformation.mfg !=NULL)
        Cy_BLE_DISS_SetCharacteristicValue(CY_BLE_DIS_MANUFACTURER_NAME, strlen(myDeviceInformation.mfg), (uint8_t *)myDeviceInformation.mfg);  
    if( myDeviceInformation.model !=NULL)
        Cy_BLE_DISS_SetCharacteristicValue(CY_BLE_DIS_MODEL_NUMBER, strlen(myDeviceInformation.model), (uint8_t *)myDeviceInformation.model);
    if( myDeviceInformation.SN !=NULL)
        Cy_BLE_DISS_SetCharacteristicValue(CY_BLE_DIS_SERIAL_NUMBER, strlen(myDeviceInformation.SN), (uint8_t *)myDeviceInformation.SN);
    if( myDeviceInformation.FMWARE !=NULL)
        Cy_BLE_DISS_SetCharacteristicValue(CY_BLE_DIS_FIRMWARE_REV, strlen(myDeviceInformation.FMWARE), (uint8_t *)myDeviceInformation.FMWARE);
}

void ble_init(void)
{
    NotificationEnabled = (notif_en){0,0,0,0,0,};
    memset((void*)&ble_param, 0, sizeof(ble_param));
    Cy_BLE_Start(ble_StackEventHandler);  
    ble_update_deviceInfo();
}

char debug_print[24];
void ble_loop(void)
{
    Cy_BLE_ProcessEvents();
    if( NotificationEnabled.temperature == 1 && ble_param.temperature.handler == (uint8_t)WRITE_NOTIF )
    {
        int16 tp_d = (int16) (ble_param.temperature.value*100);
        notificationPacket.connHandle = cy_ble_connHandle[0];
        notificationPacket.handleValPair.attrHandle = CY_BLE_SENSOR_TEMPERATURE_CHAR_HANDLE;
        notificationPacket.handleValPair.value.val = (uint8_t*)&tp_d;
        notificationPacket.handleValPair.value.len = sizeof(tp_d);
        ble_param.temperature.handler = (uint8_t)DO_NOTHING;
        Cy_BLE_GATTS_Notification(&notificationPacket);  
    };
    if( NotificationEnabled.pressure == 1 && ble_param.pressure.handler == (uint8_t)WRITE_NOTIF)
    {
        uint32 tp_pres = (uint32) (ble_param.pressure.value*10);
        notificationPacket.connHandle = cy_ble_connHandle[0];
        notificationPacket.handleValPair.attrHandle = CY_BLE_SENSOR_PRESSURE_CHAR_HANDLE;
        notificationPacket.handleValPair.value.val = (uint8_t*)&tp_pres;
        notificationPacket.handleValPair.value.len = sizeof(tp_pres);
        ble_param.pressure.handler = (uint8_t)DO_NOTHING;
        Cy_BLE_GATTS_Notification(&notificationPacket);
    };
    if( NotificationEnabled.custom_param == 1 && ble_param.custom.handler == (uint8_t)WRITE_NOTIF)
    {
        notificationPacket.connHandle = cy_ble_connHandle[0];
        notificationPacket.handleValPair.attrHandle = CY_BLE_SENSOR_CUSTOM_VARIABLE_CHAR_HANDLE;
        notificationPacket.handleValPair.value.val = (uint8_t*)&ble_param.custom.value;
        notificationPacket.handleValPair.value.len = sizeof(ble_param.custom.value);
        ble_param.custom.handler = (uint8_t)DO_NOTHING;
        Cy_BLE_GATTS_Notification(&notificationPacket);
    };
    if( NotificationEnabled.battery == 1 && ble_param.battery_level.handler == (uint8_t)WRITE_NOTIF)
    {
        uint8_t tmp = (uint8_t)ble_param.battery_level.value;
        notificationPacket.connHandle = cy_ble_connHandle[0];
        notificationPacket.handleValPair.attrHandle = CY_BLE_SENSOR_BATTERY_LEVEL_CHAR_HANDLE;
        notificationPacket.handleValPair.value.val = (uint8_t*)&tmp;
        notificationPacket.handleValPair.value.len = sizeof(tmp);
        ble_param.battery_level.handler = (uint8_t)DO_NOTHING;
        Cy_BLE_GATTS_Notification(&notificationPacket);
    };
    cy_stc_ble_conn_handle_t appConnHandle;
    if((Cy_BLE_GetConnectionState(appConnHandle) >= CY_BLE_CONN_STATE_CONNECTED) && ble_param.BAS.handler == (uint8_t)WRITE_NOTIF )
    {   
       uint8_t bt = (uint8_t)ble_param.BAS.value; 
       Cy_BLE_BASS_SendNotification(appConnHandle, CY_BLE_BAS_BATTERY_LEVEL, CY_BLE_BAS_BATTERY_LEVEL, sizeof(bt), &bt);        
        /* Update Battery Level characteristic value */
       Cy_BLE_BASS_SetCharacteristicValue(CY_BLE_BAS_BATTERY_LEVEL, CY_BLE_BAS_BATTERY_LEVEL,sizeof(bt), &bt);
       ble_param.BAS.handler = (uint8_t)DO_NOTHING;
    }
        
}


void ble_write_req_event(uint32_t desc, uint8_t notifEnabled)
{
    
    switch(desc)
    {
        case CY_BLE_SENSOR_TEMPERATURE_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE:
            NotificationEnabled.temperature = notifEnabled;
            break;
        case CY_BLE_SENSOR_PRESSURE_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE:
            NotificationEnabled.pressure = notifEnabled;
            break;
        case CY_BLE_SENSOR_BATTERY_LEVEL_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE:
            NotificationEnabled.battery = notifEnabled;
            break;
        case CY_BLE_SENSOR_CUSTOM_VARIABLE_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE:
            NotificationEnabled.custom_param = notifEnabled;
            break;
    }
}

void ble_StackEventHandler(uint32 event, void* eventParam)
{
    cy_stc_ble_gatt_write_param_t *write_req_param;
    (void)*eventParam;
    sprintf(debug_print, "\r\n EVENT : 0x%x \r\n",event);
    UART_PutString(debug_print);
    write_req_param = (cy_stc_ble_gatt_write_param_t *)eventParam;
    sprintf(debug_print, "\r\n handle ATTR : 0x%x \r\n",write_req_param->handleValPair.attrHandle);
    UART_PutString(debug_print);
    cy_stc_ble_conn_handle_t connHandle = write_req_param->connHandle;
    uint16_t cccd;
    switch(event)
    {
        case CY_BLE_EVT_STACK_ON:
            Cy_BLE_GAPP_StartAdvertisement(CY_BLE_ADVERTISING_FAST, CY_BLE_PERIPHERAL_CONFIGURATION_0_INDEX);
            break;

        case CY_BLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
            UART_PutString("\r\n BLE Advertisement Started \r\n");
            break;

        case CY_BLE_EVT_GAP_DEVICE_CONNECTED:
            UART_PutString("\r\n BLE device connected \r\n");
            break;
        case CY_BLE_EVT_GAP_DEVICE_DISCONNECTED:
            UART_PutString("\r\n BLE device dis connected \r\n");
            NotificationEnabled = (notif_en){0,0,0,0,0};
            Cy_BLE_GAPP_StartAdvertisement(CY_BLE_ADVERTISING_FAST, CY_BLE_PERIPHERAL_CONFIGURATION_0_INDEX);
            break;
        case CY_BLE_EVT_GATTS_WRITE_REQ:
                UART_PutString("\r\n BLE write req \r\n");
                write_req_param = (cy_stc_ble_gatt_write_param_t *)eventParam;
                ble_write_req_event(write_req_param->handleValPair.attrHandle,write_req_param->handleValPair.value.val[0]);
                Cy_BLE_GATTS_WriteRsp(write_req_param->connHandle);
                break;
        case CY_BLE_EVT_GATTS_READ_CHAR_VAL_ACCESS_REQ:
                UART_PutString("\r\n BLE READ Value \r\n");
                break;
        case CY_BLE_EVT_GATT_CONNECT_IND:
                break;
    }
}

/* [] END OF FILE */
