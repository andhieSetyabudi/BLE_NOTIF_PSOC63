/***************************************************************************//**
* \file CY_BLE_ess_config.c
* \version 2.20
* 
* \brief
*  This file contains the source code of initialization of the config structure
*  for the Environmental Sensing Service.
*
********************************************************************************
* \copyright
* Copyright 2017-2019, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "ble/cy_ble_ess.h"

#if(CY_BLE_MODE_PROFILE && defined(CY_BLE_ESS))
#ifdef CY_BLE_ESS_SERVER
/* Number of ESS characteristics instances */
static uint8_t cy_ble_esssCharInstances[0x15u] = {
    0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u,
    0x00u, 0x00u, 0x00u, 0x00u, 0x00u
};

static const cy_stc_ble_esss_t cy_ble_esss =
{
    .serviceHandle   = 0x001Cu, /* Handle of the ESS service */
    {
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
        , 
    },
};

#endif /* CY_BLE_ESS_SERVER */

#ifdef CY_BLE_ESS_CLIENT

#endif /* CY_BLE_ESS_CLIENT */

/**
* \addtogroup group_globals
* @{
*/

/** The configuration structure for the Environmental Sensing Service. */
cy_stc_ble_ess_config_t cy_ble_essConfig =
{
    /* Service GATT DB handles structure */
    #ifdef CY_BLE_ESS_SERVER
        .esss = &cy_ble_esss,
        .esssCharInstances = cy_ble_esssCharInstances,
    #else
        .esss = NULL,
        .esssCharInstances = NULL,
    #endif /* CY_BLE_ESS_SERVER */

    #ifdef CY_BLE_ESS_CLIENT
        .essc = cy_ble_essc,
        .esscCharInstances = cy_ble_esscCharInstances,
    #else
        .essc = NULL,
        .esscCharInstances = NULL,
    #endif /* CY_BLE_ESS_CLIENT */
    
    /* An application layer event callback function to receive service events from the BLE Component. */
    .callbackFunc = NULL,
};

/** @} group_globals */
#endif /* (CY_BLE_MODE_PROFILE && defined(CY_BLE_ESS)) */

/* [] END OF FILE */
