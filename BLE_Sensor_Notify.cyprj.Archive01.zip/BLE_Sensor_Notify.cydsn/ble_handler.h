/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * andhie setyabudi
 * https://github.com/andhieSetyabudi/BLE_NOTIF_PSOC63
 * ========================================
*/
#ifndef _ble_handler_h_
#define _ble_handler_h_

#include "stdio.h"
#include "project.h"
#include "string.h"

typedef enum{
    TEMPERATURE_IDX = 0, // Temperature in sensor service
    PRESSURE_IDX,       // Pressure in sensor service
    BATTERY_LEVEL_IDX,  // Battery level in Sensor Service
    CUSTOM_PARAM_IDX,   // Custom param in Sensor Service
    BAS_LEVEL,          // Battery level in BAS service
}ble_param_index;

typedef enum{
    DO_NOTHING = 0,
    WRITE_NOTIF,
}notif_stat;

typedef struct{
    uint8_t temperature,
            pressure,
            battery,
            custom_param,
            BAS;
}notif_en;

typedef struct{
    char8 *mfg,
          *model,
          *SN,
          *FMWARE;
}deviceInfo_t;

typedef struct{
    float value;
    uint8_t handler;
}content_t;

typedef struct{
    content_t temperature,      // Temperature in sensor service
              pressure,         // Pressure in sensor service
              battery_level,    // Battery level in Sensor Service
              custom,           // Custom param in Sensor Service
              BAS;              // Battery level in BAS service
}sensor_param;



cy_stc_ble_gatts_handle_value_ntf_t notificationPacket;


extern deviceInfo_t myDeviceInformation;
notif_en NotificationEnabled;
sensor_param ble_param;

void ble_init(void);
void ble_loop(void);
void ble_updateDeviceInformation(deviceInfo_t *info);
void ble_updateManufacturer_name(char8* name); 
void ble_updateModel(char8* model);            
void ble_updateSN(char8* SN);                  
void ble_updateFirmwareVersion(char8* version);

void ble_updateBatteryValue(float battery_percent);
void ble_updateTemperatureValue(float temperature);
void ble_updatePressureValue(float pressure);
void ble_updateCustomParamValue(float val);
void ble_updateBASValue(uint8_t level);

void ble_updateValueParam(ble_param_index id, float value);

static void ble_StackEventHandler(uint32 event, void* eventParam);


extern cy_stc_ble_conn_handle_t cy_ble_connHandle[CY_BLE_CONN_COUNT];
#endif
/* [] END OF FILE */
