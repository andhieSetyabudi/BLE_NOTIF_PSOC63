/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "inttypes.h"
#include "bsp_helper.h"
#include "BMP280.h"
#include "ble_handler.h"

const char8* manufacturer_name = "my.inc";
const char8* model             = "my_bt";
const char8* version           = "0.0.1.2023";
const char8* SN                = "bt-123";

#define SYS_TICK_INTERVAL_1mS	(32768/1000)-1
uint32 tickCount;

void SysTickCallback(void) { tickCount++; }
uint32_t getTick()  { return tickCount; }

uint32_t bmp_write_bytes(uint8_t addr, uint8_t *data, uint8_t dataLen, uint32_t timeout)
{
    cy_en_scb_i2c_status_t status;
    I2C_MasterSendStart((uint32_t)addr,CY_SCB_I2C_WRITE_XFER,timeout);
    for(uint8_t i = 0; i<dataLen; i++)
        status |= I2C_MasterWriteByte(data[i], timeout);
    status = I2C_MasterSendStop(100);
    return (uint32_t)status;
}

uint32_t bmp_read_bytes(uint8_t addr, uint8_t reg, uint8_t *val, uint8_t dataLen, uint32_t timeout)
{
    cy_en_scb_i2c_status_t status;
    I2C_MasterSendStart((uint32_t)addr,CY_SCB_I2C_WRITE_XFER,timeout);
    if( CY_SCB_I2C_SUCCESS == I2C_MasterWriteByte(reg, timeout) )
    {
        I2C_MasterSendReStart((uint32_t)addr,CY_SCB_I2C_READ_XFER,timeout);
        for( uint8_t i = 0; i< dataLen-1; i++)
             I2C_MasterReadByte(CY_SCB_I2C_ACK, val++, timeout);
        I2C_MasterReadByte(CY_SCB_I2C_NAK, val, timeout);
    }
    status = I2C_MasterSendStop(timeout);
    return (uint32_t)status;
}


int main(void)
{
    __enable_irq(); /* Enable global interrupts. */

    UART_Start();
    
    UART_PutString("Hello\r\n");
    char buf_txt[25]; char strF[10];
    uint8_t btn_state;
    
    // setup systick
    Cy_SysTick_Init(CY_SYSTICK_CLOCK_SOURCE_CLK_LF, SYS_TICK_INTERVAL_1mS);
	Cy_SysTick_SetCallback(0,SysTickCallback);
    uint32_t lastTick = 0;
    
    
    
    // setup I2C
    I2C_Start();
    
    // initialize the sensor
    if( bmp280.init(BMP280_ADDR, bmp_read_bytes, bmp_write_bytes) == BMP280_SUCCESS )
         UART_PutString("Device Found !\r\n");
    float tp, press;
        
  // setup BLE
    // Setup device information
    deviceInfo_t myInfo = {
                            .mfg = (char8*)manufacturer_name,
                            .model = (char8*)model,
                            .SN = (char8*)SN,
                            .FMWARE = (char8*)version,
                           };
    ble_updateDeviceInformation(&myInfo);
    ble_init();
    uint32_t notif_tick = 0;
    float simu_battery = 0;
    for(;;)
    {
        if( getTick() - notif_tick >= 1000)
        {
            ble_updatePressureValue(press);
            ble_updateTemperatureValue(tp);
            simu_battery+=0.25f;
            simu_battery = simu_battery > 100? 0:simu_battery;
            ble_updateBASValue(simu_battery);
            ble_updateBatteryValue(simu_battery);
            
            // updating custom_service value
            ble_updateCustomParamValue(tp);
            uint8_t bufFloat[4];
            floatToFourByte(bufFloat,tp);
            sprintf(buf_txt,(const char*)("custom serviec val (hex): 0x%x%x%x%x\r\n"), bufFloat[3],
                                                                                       bufFloat[2],
                                                                                       bufFloat[1],
                                                                                       bufFloat[0] );
            UART_PutString(buf_txt);
            notif_tick = getTick();
        };
        ble_loop();        
        if( getTick() - lastTick >= 1000)
        {
            btn_state = Cy_GPIO_Read(button_PORT,button_NUM);
            sprintf(buf_txt,(const char*)("state_button : %u \t %u\r\n"), btn_state, getTick());
            UART_PutString(buf_txt);
            Cy_GPIO_Inv(P7_1_PORT, P7_1_NUM);
            bmp280.readValue(&tp, &press, 100);
            sprintf(buf_txt,(const char*)("temp : %s \t"), ftoa(tp,strF,2));
            UART_PutString(buf_txt);
            sprintf(buf_txt,(const char*)("press : %sPa \t"), ftoa(press,strF,2));
            UART_PutString(buf_txt);
            sprintf(buf_txt,(const char*)("battery : %s%%\r\n"), ftoa(simu_battery,strF,2));
            UART_PutString(buf_txt);
            
            lastTick = getTick();
        }
    }
}

/* [] END OF FILE */
